# TXG Information — Crimson X (Render)

## Features
- Crimson X black/red responsive dashboard
- 01 All APIs: built-in tools + custom API directory
- 02 Add New API: name + HTTPS URL containing `{Message}`
- 03 Total APIs: live custom API count
- 04 Special Zone: favourite custom APIs
- 05 Remove APIs: confirmation before deletion
- Custom API response displayed on the same website
- Built-in public IP metadata, DNS, URL metadata, India PIN and IFSC lookups

## Deploy on Render
1. Upload this folder to a GitHub repository.
2. Render Dashboard → New → Web Service → connect repository.
3. Runtime: Node. Build Command: `npm install`. Start Command: `npm start`.
4. Environment Variables:
   - `ADMIN_PASSWORD` = a long unique admin password
   - `DATA_FILE` = `/var/data/apis.json` (only if using a mounted persistent disk)
5. Add a Render persistent disk mounted at `/var/data` so saved APIs survive restarts/redeploys. Without persistent storage, local file data may be lost on redeploy/restart.

## Custom API format
Example URL: `https://your-provider.example/api?query={Message}`
- Use HTTPS only.
- The provider should return JSON.
- User input is URL-encoded before inserting in the URL.
- Keep provider API keys server-side; do not put secret keys into public browser code.
- Only add APIs you are authorized to use. Do not connect APIs intended to reveal private personal data.

## Admin
Tap ADMIN LOGIN and enter the value configured in Render `ADMIN_PASSWORD`. The first admin form uses a test authentication request to validate the password; it does not save the test API.
